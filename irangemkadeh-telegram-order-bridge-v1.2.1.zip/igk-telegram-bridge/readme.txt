=== IranGemKadeh Telegram Order Bridge ===
Contributors: irangemkadeh
Tags: woocommerce, telegram, orders
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.2.0

Connects the existing Order to Telegram Notifier group to a second work group.

== Setup ==
1. Install and activate this plugin. Keep the existing Order to Telegram Notifier plugin active.
2. In WooCommerce > پل ارتباطی تلگرام, enter the NEW bot token, group 1 ID and group 2 ID.
3. Add the new bot to both groups. It must be able to send messages and react in group 1, and be an administrator in group 2.
4. Save settings, then click ثبت وب‌هوک.
5. Reply to a copied order message in group 2 with 1✅ (success) or ❌ / 1❌ (failure).

The bridge captures the original notifier's Telegram message ID from the successful sendMessage HTTP response. It does not create a second order message in group 1. It copies the original order text to group 2, then replies to the original group 1 message with "✅ 1" or "❌" and sets the configured reaction on that original message.

For compatibility with the existing notifier, the bridge relays the verified result to the existing /ott-webhook endpoint. The old notifier then performs its own WooCommerce status update and dollar-counter logic. This is necessary because Telegram does not deliver messages authored by one bot to another bot as updates.

== Notes ==
- Order IDs are unique in the bridge database to prevent duplicate forwarding.
- Each work-group order can be finalized once.
- If the legacy webhook relay fails, the row is marked legacy_error and can be retried from the settings page.
- The plugin itself does not directly update WooCommerce order statuses.


Version 1.2.1: Added exclusions for WooCommerce order statuses. Orders with a status label containing کارت به کارت are automatically ignored; additional statuses can be selected in WooCommerce > Telegram Bridge settings.
